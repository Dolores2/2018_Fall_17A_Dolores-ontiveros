/* Dolores Ontiveros         CSC-17A      Chapter 7,  P. 444, #4
/*
/***************************************************************
* Calculate Larger value
*
* ______________________________________________________________
* This program displays larger values than input integer 
* is given array.
*
* ______________________________________________________________
* INPUT-
* Test array
* 
* OUTPUT-
* Displays the number bigger than the comapared number.
* 
* CONSTANTS-
* size_of_array:
*
**************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;


void output_Larger_Than(int array_To_Test[],
		    int number_To_Test,
		    int array_Size)
{
  for (int i = 0; i < array_Size; i++)
	{
	if (number_To_Test < array_To_Test[i])
		cout << array_To_Test[i] << endl;
	}
}

int main() 
{
	Const int SIZE_OF_ARRAY = 5;

	int test_Array(SIZE_OF_ARRAY) = {1, 10, 15, 20, 30}
	int compared_Number;

	compared_Number = 14;
	output_Larger_Than(test_Array, compared_Number, SIZE_OF_ARRAY);
	return 0;
}