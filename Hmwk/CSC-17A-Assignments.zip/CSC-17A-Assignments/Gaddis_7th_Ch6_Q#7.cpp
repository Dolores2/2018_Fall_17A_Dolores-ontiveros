/* Dolores Ontiveros        CSC-17A       Chapter 6, P. 370, #7
/*
/**************************************************************
* Celsius Temperature Table Converter:
*
* ______________________________________________________________
* This program converts a Fahrenheit Temperature, which is 
* entered by the user, to celcius degrees.
* ______________________________________________________________
* INPUT-
* start: Sentinal value using Y or N to begin or end the program.
* fahrenheitTemp : fahrenheit temperature.
* 
* OUTPUT-
* celcius: Function that uses the formula:
*	 (fahrenheit - 32) * 5 / 9
*
**************************************************************/
 
#include <iostream>
#include <iomanip>
using namespace std;
 
// Function Prototype
void celcius (float);
 
int main() 
{
 
// Variables
float fahrenheit;          // Function variable
float fahrenheitTemp;     // Input variable
char start;              // Sentinal variable
 
// Beginning program prompt
	cout << "You will be prompted to enter a temperature in fahrenheit" << endl;
	cout << "You will enter only a whole number" << endl;
	cout << "Do you wish to continue (Enter Y to continue or N to exit)" << endl;
	cout << " " << endl;
	cin >> start;
	cout << start;
	cout << " " << endl;
 
// Validation Loop for 'start' input
while (start != 'y' && start != 'Y' && start != 'n' && start != 'N')
{
	cout << " " << endl;
	cout << "Invalid input" << endl;;
	cout << "Enter Y to continue or N to exit" << endl;
	cout << " " << endl;
	cin >> start;
	cout << start;
	cout << endl;
}
// while program loop
	while (start != 'n' && start != 'N')
{ 
	cout << " " << endl;
	cout << "Enter a temperature in fahrenheit" << endl;
	cin >> fahrenheitTemp ;
	cout << fixed << setprecision(2) << fahrenheitTemp << endl;

// Calling function "calculateRetail"
celcius (fahrenheitTemp);
	cout << endl;
		
// Statement for ending or begining program
	cout << "Do you wish to continue (Enter Y to continue or N to exit)" << endl;
	cout << " " << endl;
	cin >> start;
	cout << start;
	cout << " " << endl;
	 
// Validation Loop for 'start' input
while (start != 'y' && start != 'Y' && start != 'n' && start != 'N')
{
	cout << " " << endl;
	cout << "Invalid input" << endl;;
	cout << "Enter Y to continue or N to exit" << endl;
	cout << " " << endl;
	cin >> start;
	cout << start;
	cout << endl;
}
 
} 
     return 0;
} // Main closing brace
 
// Function definition for 'calculateRetail'
void celcius (float fahrenheit)
{
	cout << "Temperature in celcius is: " ;
	cout << fixed << setprecision(2) <<
	(fahrenheit - 32) * 5 / 9;
	cout << endl;
}
