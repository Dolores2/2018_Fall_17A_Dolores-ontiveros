/* Dolores Ontiveros        CSC-17A       Chapter 8,  P. 487, #1
/*
/***************************************************************
* Calculate Charge Account Validation
*
* ______________________________________________________________
* This program uses a simple linear search to locate an account 
* number entered by the user.
* ______________________________________________________________
* INPUT- 
* ACCOUNT_NUMBERS:
* 
* OUTPUT-
* Validated Account Number:
*
**************************************************************/
#include <iostream>
using namespace std;

 int searchList(const int[], int, int);
 
const int ACCOUNT_NUMBERS = 18;
 
int main() 
{
// Initializing variables
int accountNum[ACCOUNT_NUMBERS] = 
		   {5658845, 4520125, 7895122, 8777541, 8451277, 1302850,
		    8080152, 5462555, 5552012, 5050552, 7825877, 1250255, 
		    1005231, 6545231, 3852085, 7576651, 7881200, 4581002};
int user_Account_Input;
int results;\
bool flag = true;
 
 // Input.
cout << "Enter a 7-digit account number: ";
cin >> user_Account_Input;
 
// 
while(flag)
{
     results = searchList(accountNum, ACCOUNT_NUMBERS, user_Account_Input);
 
// Initialize If statement.
if(results == -1)
      {
      cout << "\nERROR!! This account number " << user_Account_Input << " is invalid!";
      cout << "\nTry again! Enter a different account number.";
      cin >> user_Account_Input;
      }
else 
      {
      cout << "\nThis account number " << user_Account_Input << " is valid.";
      flag = false;
      }
   }
   return 0;
}
 
//**********************************************************************
// This function uses a linear search to check the charge validation.  *
//**********************************************************************
 
int searchList (const int accountNum[], int ACCOUNT_NUMBERS, int user_Account_Input)
{
       int index = 0;
       int position = -1;
       bool found = false;
 
       while(index < ACCOUNT_NUMBERS && !found)
       {
       	if(accountNum[index] == user_Account_Input)
       	{
       	      found = true;
       	      position = index; 
       	}
       	index++;
       }
       return position;
}