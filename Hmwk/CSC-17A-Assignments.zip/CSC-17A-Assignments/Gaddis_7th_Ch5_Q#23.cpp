/* Dolores Ontiveros        CSC-17A       Chapter 5, P. 298, #23
/*
/***************************************************************
/* Pattern Displays:
 * 
 *
 *
 ***************************************************************
 * This program displays two patterns A and B. 
 *
 *
 ***************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;
 
int main ()
{
	int symbolCount;    
	char patternShape; 

	symbolCount = 10;
	patternShape = '+';

	cout << left;
	cout << setw(20) << "Pattern A" ;
	cout << setw(20) << "Pattern B" << endl;
	cout << setfill('_');
	cout << setw(40) << '_' << endl;
	cout << setfill(' ');
	for(int a = 1 ; a <= symbolCount ; a++)
	{
	for(int b = 1 ; b <= a ; b++)
	{
	cout <<  patternShape;
	}
	cout << setw(20-a) << ' ';
	for(int c = a ; c <= symbolCount ; c++)
	{
	cout << patternShape;
	}
	cout << endl;
	}
	return 0;
}
 