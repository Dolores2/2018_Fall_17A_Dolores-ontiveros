/* Dolores Ontiveros         CSC-17A       Chapter 8,  P. 488, #6
/*
/****************************************************************
* STRING-SELCTION-SORT: NAMES
*________________________________________________________________
* This program sorts names by alphabetical order. The program 
* then will ask the user if they would like to see the results 
* again.
*________________________________________________________________
* INPUT-
*   Repeat Input Data: Either a (y) or (n) to determine whether 
*   or not to run again.
* OUTPUT-
*   N/A
*****************************************************************/
#include <iostream>
#include <string>
using namespace std;
 
// Constants
const int NUM_NAMES = 20;
 
//Function protoypes
void selectionSort(string [], int);
void showArray(const string [] , int);
 
int main() 
{
   const int NUM_NAMES = 20;
   string names [NUM_NAMES] = 
   {"Collins, Bill", "Smith, Bart", "Allen, Jim",
    "Griffin, Jim", "Stamey, Marty", "Rose, Geri",
    "Taylor, Terri", "Johnson Jill", 
    "Allison, Jeff", "Looney, Joe", "Wolfe, Bill",
    "James, Jean", "Weaver, Jim", "Pore, Bob",
    "Rutherford, Greg", "Javens, Renee",
    "harrison, Rose", "setzer, Cathy",
    "Pike, Gordon", "Holland, Beth" };

//Press "y or Y" to repeat
char again; 
 
do
{

    cout << "The unsortedable names are\n";
    showArray(names, NUM_NAMES);
 
    // Initialize Selection Sort. 
    selectionSort(names, NUM_NAMES);
 
    // Sorted arrays.
    cout << "The sorted NAMES are\n";
    showArray(names, NUM_NAMES);
 
    // Enter "y or Y" to re-run program. 
    cout << "Would you like to run the program again? (Y/N): ";
    cin >> again;
}while(again == 'y' || again == 'Y');
 
return 0;
}

//***********************************************************
// This function display's the variables inside the array.  *
//***********************************************************
 
void showArray(const string array[], int NUM_NAMES)
{
    for(int count = 0 ; count < NUM_NAMES; count ++)
    cout << array[count] << endl;
 
}
 
//*******************************************************
// This function sorts the variables inside the array.  *
//*******************************************************
 
void selectionSort(string array[], int NUM_NAMES)
{
int startScan, minIndex;
string minValue;
 
for(startScan = 0; startScan < (NUM_NAMES -1); startScan++)
{
    minIndex = startScan;
    minValue = array[startScan];
    for(int index = startScan +1; index < NUM_NAMES; index++)
    {
        if (array[index] < minValue)
        {
            minValue = array[index];
            minIndex = index;
        }
    }
    array[minIndex] = array[startScan];
    array[startScan] = minValue;
   }
}